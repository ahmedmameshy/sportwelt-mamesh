# Sportwelt / Mamesh German Project

## التشغيل
افتح `project.html` أو `index.html` مباشرة في المتصفح.
يفضل استخدام Chrome/Edge.

## الملفات
- project.html: الصفحة الرئيسية
- mamesh.html: صفحة Mamesh الجديدة
- style.css: كل التصميم والأنيميشن
- Script.js: التفاعل والـ JavaScript
- assets/: الصور الأصلية + صور SVG جديدة للرياضات المضافة

## الرياضات
Basketball, Schwimmen, Fußball, Laufen, Tennis, Radfahren, Volleyball,
Boxen, Handball, Turnen, Tischtennis, Leichtathletik.

تم الحفاظ على المحتوى الألماني الأصلي للفقرات الموجودة، مع توسيع الموقع وإضافة أقسام جديدة.
